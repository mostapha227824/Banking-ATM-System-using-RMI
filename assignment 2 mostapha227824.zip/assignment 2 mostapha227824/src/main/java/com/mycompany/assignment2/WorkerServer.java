package com.mycompany.assignment2;



import java.rmi.Remote;
import java.rmi.RemoteException;

interface WorkerServer extends Remote {
    double checkBalance(int clientId) throws RemoteException;
    void withdraw(int clientId, double amount) throws RemoteException;
    void deposit(int clientId, double amount) throws RemoteException;
    int addClient() throws RemoteException; // adding method to generate unique client IDs....
}
