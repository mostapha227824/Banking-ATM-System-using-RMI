/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assignment2;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.rmi.Remote;

public class BankSystem {
    static BankGUI B_GUI;
    static ClientGUI C_GUI;
    public static void main(String[] args) throws RemoteException {
         B_GUI = new BankGUI();
            B_GUI.setVisible(true);
              C_GUI = new ClientGUI();
            C_GUI.setVisible(true);
             C_GUI.appendTextArea("Welcome to Bue Commercial Bank");
            
        Scanner scanner = new Scanner(System.in);

        System.out.println("Select the branch number:");
        System.out.println("1. Sharm El Sheikh");
        System.out.println("2. Hurgada");
        System.out.println("3. El Gouna");
        System.out.println("4. El Shrouk");
        System.out.println("5. New Cairo");
        System.out.println("6. Nasr City");
        
        C_GUI.appendTextArea("Select the branch number:");
        C_GUI.appendTextArea("1. Sharm El Sheikh");
        C_GUI.appendTextArea("2. Hurgada");
        C_GUI.appendTextArea("3. El Gouna");
        C_GUI.appendTextArea("4. El Shrouk");
        C_GUI.appendTextArea("5. New Cairo");
        C_GUI.appendTextArea("6. Nasr City");
        
               


        
        System.out.print("Enter the branch number: ");
        int branchNumber = scanner.nextInt();
        scanner.nextLine(); // Consuming newline character....

        
        // Connect the client to the appropriate master server based on the branch number...
        MasterServer masterServer = connectToMasterServer(branchNumber);

        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Check Balance");
            System.out.println("2. Withdraw");
            System.out.println("3. Deposit");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            
            
//......................
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consuming newline character

            switch (choice) {
                case 1:
                    checkBalance(masterServer);
                    break;
                case 2:
                    withdraw(masterServer);
                    break;
                case 3:
                    deposit(masterServer);
                    break;
                case 4:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }

    private static MasterServer connectToMasterServer(int branchNumber) {
    
    String[] branchNames;
    if (branchNumber >= 1 && branchNumber <= 3) {
        branchNames = new String[]{"sharmElSheikh", "hurgada", "elGouna"};
    } else if (branchNumber >= 4 && branchNumber <= 6) {
        branchNames = new String[]{"elShrouk", "newCairo", "nasrCity"};
    } else {
        System.out.println("Invalid branch number. Exiting...");
         B_GUI.appendTextArea("Failed to Connect to Master server");
        System.exit(0);
        return null;
    }

    return new MasterServerImpl(null, branchNames);
}

    private static void checkBalance(MasterServer masterServer) throws RemoteException {
    Scanner scanner = new Scanner(System.in);
    System.out.print("Enter client ID: ");
     C_GUI.appendTextArea(" Enter client ID:");
    int clientId = scanner.nextInt();
    double balance = masterServer.checkBalance(getWorkerId(clientId), clientId);
    System.out.println("Balance for " + clientId + ": " + balance);
     C_GUI.appendTextArea("Balance for " + clientId + ": " + balance);
     
}
    

private static void withdraw(MasterServer masterServer) throws RemoteException {
    Scanner scanner = new Scanner(System.in);
    System.out.print("Enter client ID: ");
     C_GUI.appendTextArea("Enter client ID: ");
    int clientId = scanner.nextInt();
    System.out.print("Enter amount to withdraw: ");
     C_GUI.appendTextArea("Enter amount to withdraw: ");
    double amount = scanner.nextDouble();
    masterServer.withdraw(getWorkerId(clientId), clientId, amount);
    System.out.println("Withdrawal successful.");
     C_GUI.appendTextArea("Withdrawal successful.");
}

private static void deposit(MasterServer masterServer) throws RemoteException {
    Scanner scanner = new Scanner(System.in);
    System.out.print("Enter client ID: ");
     C_GUI.appendTextArea("Enter client ID: ");
    int clientId = scanner.nextInt();
    System.out.print("Enter amount to deposit: ");
     C_GUI.appendTextArea("Enter amount to deposit: ");
    double amount = scanner.nextDouble();
    masterServer.deposit(getWorkerId(clientId), clientId, amount);
    System.out.println("Deposit successful.");
     C_GUI.appendTextArea("Deposit successful. ");
}

    
   private static String getWorkerId(int clientId) {
   
    
    if (clientId >= 1 && clientId <= 5) {
        return "sharmElSheikh"; // Worker server for clients 1 to 5
    } else if (clientId >= 6 && clientId <= 10) {
        return "hurgada"; 
    } else if (clientId >= 11 && clientId <= 15) {
        return "elGouna"; 
    } else if (clientId >= 16 && clientId <= 20) {
        return "elShrouk"; 
    } else if (clientId >= 21 && clientId <= 25) {
        return "newCairo"; 
    } else if (clientId >= 26 && clientId <= 30) {
        return "nasrCity"; // Worker server for clients 26 to 30
    } else {
        return null; // Invalid client ID
    }
}
   

}