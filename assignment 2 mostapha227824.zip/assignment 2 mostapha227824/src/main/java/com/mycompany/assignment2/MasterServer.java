package com.mycompany.assignment2;

import java.rmi.Remote;
import java.rmi.RemoteException;

interface MasterServer extends Remote {
    double checkBalance(String workerId, int clientId) throws RemoteException;
    void withdraw(String workerId, int clientId, double amount) throws RemoteException;
    void deposit(String workerId, int clientId, double amount) throws RemoteException;
    void updateClientData(String workerId, int clientId, double balance) throws RemoteException;
    void setOtherMasterServer(MasterServer otherMasterServer) throws RemoteException;
}
