package com.mycompany.assignment2;

import static com.mycompany.assignment2.BankSystem.B_GUI;
import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;

class MasterServerImpl implements MasterServer {
    private Map<String, WorkerServer> workerServers; // to store worker servers....
    private Map<String, Map<Integer, Double>> clientData; // store client data nestedmap.....
    private MasterServer otherMasterServer; // Reference to the second master server...

     public MasterServerImpl(MasterServer otherMasterServer, String[] workerIds) {
        workerServers = new HashMap<>();
        clientData = new HashMap<>();
        this.otherMasterServer = otherMasterServer;

        // Initializeing worker servers specified for this master server....
        try {
            for (String workerId : workerIds) {
                WorkerServer workerServer = new WorkerServerImpl();
                workerServers.put(workerId, workerServer);

                // Initialize clients for each worker server.....
                for (int i = 1; i <= 5; i++) {
                    int clientId = workerServer.addClient(); // adding a client to the worker server....
                    System.out.println("Client " + clientId + " added to worker server " + workerId);
                    B_GUI.appendTextArea("Client " + clientId + " added to worker server " + workerId);
                }
            }

            // initialize client data (retrieve from worker servers)....
            for (String workerId : workerIds) {
                WorkerServer workerServer = workerServers.get(workerId);
                Map<Integer, Double> workersClientData = new HashMap<>(); // creating an empty HashMap for each worker ID in the clientData map to store the client data....
                clientData.put(workerId, workersClientData);
            }
        } catch (RemoteException e) {
            e.printStackTrace(); 
        }
    }

    @Override
    public double checkBalance(String workerId, int clientId) throws RemoteException {
        WorkerServer workerServer = workerServers.get(workerId);
        if (workerServer != null) {
            return workerServer.checkBalance(clientId);
        } else {
            throw new RemoteException("Invalid worker server ID");
        }
    }

    @Override
    public void withdraw(String workerId, int clientId, double amount) throws RemoteException {
        WorkerServer workerServer = workerServers.get(workerId);
        if (workerServer != null) {
            workerServer.withdraw(clientId, amount);
            updateClientData(workerId, clientId, workerServer.checkBalance(clientId));
            if (otherMasterServer != null) {
                otherMasterServer.updateClientData(workerId, clientId, workerServer.checkBalance(clientId));
            }
        } else {
            throw new RemoteException("Invalid worker server ID");
        }
    }

    @Override
    public void deposit(String workerId, int clientId, double amount) throws RemoteException {
        WorkerServer workerServer = workerServers.get(workerId);
        if (workerServer != null) {
            workerServer.deposit(clientId, amount);
            updateClientData(workerId, clientId, workerServer.checkBalance(clientId));
            if (otherMasterServer != null) {
                otherMasterServer.updateClientData(workerId, clientId, workerServer.checkBalance(clientId));
            }
        } else {
            throw new RemoteException("Invalid worker server ID");
        }
    }

    @Override
    public void updateClientData(String workerId, int clientId, double balance) throws RemoteException {
        Map<Integer, Double> workersClientData = clientData.get(workerId);
        if (workersClientData != null) {
            workersClientData.put(clientId, balance);
        }
    }

    // Setter for the other master server
    public void setOtherMasterServer(MasterServer otherMasterServer) {
        this.otherMasterServer = otherMasterServer;
    }
    
}
