package com.mycompany.assignment2;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

class WorkerServerImpl implements WorkerServer {
    private Map<Integer, Double> clients; // to store client balances...
    private AtomicInteger clientIdGenerator; // togenerate unique client IDs...

    public WorkerServerImpl() {
        clients = new HashMap<>();
        clientIdGenerator = new AtomicInteger(1); // Starting the client IDs from 1....
    }

    @Override
    public synchronized int addClient() throws RemoteException { //method is synchrnized to ensure thread safety...
        int clientId = clientIdGenerator.getAndIncrement();
        clients.put(clientId, 0.0); // initialize client balance to 0....
        return clientId;
    }

    @Override
    public double checkBalance(int clientId) throws RemoteException {
        return clients.getOrDefault(clientId, 0.0); //if the client id is not found in the map it returns 0.0
    }

    @Override
    public synchronized void withdraw(int clientId, double amount) throws RemoteException {
        Double balance = clients.get(clientId); // retreving the balance...
        if (balance != null && balance >= amount) {
            clients.put(clientId, balance - amount);
        } else {
            throw new RemoteException("Insufficient balance");
        }
    }

    @Override
    public synchronized void deposit(int clientId, double amount) throws RemoteException {
        Double balance = clients.get(clientId);
        if (balance != null) {
            clients.put(clientId, balance + amount);
        } else {
            throw new RemoteException("Client does not exist");
        }
    }
}
